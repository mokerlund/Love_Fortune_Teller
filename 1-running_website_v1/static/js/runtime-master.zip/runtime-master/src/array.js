var prototype = Array.prototype;
export var map = prototype.map;
export var forEach = prototype.forEach;
